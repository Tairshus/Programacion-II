﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guia_Ejercicios
{
    class Ejercicio_2
    {
        static double num;
        static string numS;
        static double cuadNum;
        static double cubNum;

        static void Main(string[] args)
        {
            Console.Write("Ingrese un numero: ");
            numS = Console.ReadLine();
            if (double.TryParse(numS, out num) && num > 0)
            {
                cuadNum = Math.Pow(num, 2);
                cubNum = Math.Pow(num, 3);
                Console.Write("El cuadrado es: {0} \nEl cubo es: {1}", cuadNum, cubNum);
            }
            else
            {
                Console.WriteLine("Error.");
            }
            Console.ReadKey();
        }
    }
}
