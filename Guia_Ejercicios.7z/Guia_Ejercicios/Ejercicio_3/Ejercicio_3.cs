using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guia_Ejercicios
{
    class Ejercicio_3
    {
        static int num;
        static double resto;
        static int i;
        static int j;
        static int esPrimo;

        static void Main(string[] args)
        {
            Console.Write("Ingrese un numero: ");
            if(int.TryParse(Console.ReadLine(), out num))
            {
                Console.WriteLine("Numeros primos existentes hasta el numero elegido.");
                for(i=2; i<num;i++)
                {
                    esPrimo = 1;
                    for(j=1;j<num;j++)
                    {
                        resto = i % j;
                       // Console.WriteLine("Resto: {0}", resto);
                    if(resto == 0 && j != 1 && j != i)
                    {
                       // Console.WriteLine("Dio 0 \nResto = {0} I= {1} J= {2}",resto,i,j);
                        esPrimo = 0;
                    }
                    }
                    if(esPrimo != 0)
                    {
                        Console.WriteLine("{0}", i);
                    }
                }
            }
            
            Console.ReadKey();
        }
    }
}
