﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guia_Ejercicios
{
    class Ejercicio_1
    {
        static int num1;
        static int num2;
        static int num3;
        static int num4;
        static int num5;
        static int max;
        static int min;
        static double prom;


        static void Main(string[] args)
        {
            Console.Write("Ingrese 5 numeros. \nIngrese primer numero: ");
            if(int.TryParse(Console.ReadLine(), out num1))
            {
                Console.Write("Ingrese segundo numero: ");
                if (int.TryParse(Console.ReadLine(), out num2))
                {
                    Console.Write("Ingrese tercer numero: ");
                    if (int.TryParse(Console.ReadLine(), out num3))
                    {
                        Console.Write("Ingrese cuarto numero: ");
                        if (int.TryParse(Console.ReadLine(), out num4))
                        {
                            Console.Write("Ingrese quinto numero: ");
                            if (int.TryParse(Console.ReadLine(), out num5))
                            {
                                if(num1 > num2 && num1 > num3 && num1 > num4 && num1 > num5)
                                {
                                    max = num1;
                                }
                                else if(num2 > num3 && num2 > num4 && num2 > num5)
                                {
                                    max = num2;
                                }
                                else if(num3 > num4 && num3 > num5)
                                {
                                    max = num3;
                                }
                                else if(num4 > num5)
                                {
                                    max = num4;
                                }
                                else
                                {
                                    max = num5;
                                }
                                if(num1 < num2 && num1 < num3 && num1 < num4 && num1 < num5)
                                {
                                    min = num1;
                                }
                                else if(num2 < num3 && num2 < num4 && num2 < num5)
                                {
                                    min = num2;
                                }
                                else if(num3 < num4 && num3 < num5)
                                {
                                    min = num3;
                                }
                                else if(num4 < num5)
                                {
                                    min = num4;
                                }
                                else
                                {
                                    min = num5;
                                }
                                prom = num1 + num2 + num3 + num4 + num5;
                                prom = prom / 5;

                                Console.WriteLine("El numero maximo ingresado es: {0} \nEl numero minimo ingresado es: {1} \nEl promedio es: {2}", max, min, prom);
                            }
                            else
                                Console.Write("Error.");
                        }
                        else
                            Console.Write("Error.");
                    }
                    else
                        Console.Write("Error.");
                }
                else
                    Console.Write("Error.");
            }
            else
                Console.Write("Error.");

            Console.ReadKey();
        }
    }
}
