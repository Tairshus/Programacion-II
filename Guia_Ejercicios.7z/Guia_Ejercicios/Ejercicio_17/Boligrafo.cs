﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_17
{
    public class Boligrafo
    {
        const short cantidadTintaMaxima = 100;
        private ConsoleColor color;
        private short tinta;

        public ConsoleColor getColor()
        {
            return color;
        }
        public short getTinta()
        {
            return tinta;
        }
        private void setTinta(short tinta)
        {
            short auxTinta;
            auxTinta = this.tinta;
            auxTinta = (short)(auxTinta + tinta);
            if (auxTinta >= 0 && tinta <= cantidadTintaMaxima)
            {
                this.tinta = auxTinta;
            }
            else
            {
                Console.WriteLine("Error, el nivel de tinta no puede ser {0}", auxTinta);
            }
        }
        public void recargar()
        {
            this.tinta = cantidadTintaMaxima;
        }
        public bool pintar(int gasto, out string dibujo)
        {
            bool val = true;


            dibujo = "algo";
            return val;
        }
    }
}
