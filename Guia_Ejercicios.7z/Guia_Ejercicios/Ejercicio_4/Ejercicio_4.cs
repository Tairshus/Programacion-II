﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    class Ejercicio_4
    {
        static int perfecto;
        static int contador;
        static int num = 6;
        static int resto;

        static void Main(string[] args)
        {
            while(contador != 4)
            {
                perfecto = 0;
                for(int i=1;i<num;i++)
                {
                    resto = num % i;
                    if(resto == 0)
                    {
                        //Console.WriteLine("Numero: {0}", i);
                        perfecto = perfecto + i;
                    }
                }
                if(perfecto >= 6 && perfecto == num)
                {
                    Console.WriteLine("Perfecto: {0}", perfecto);
                    contador++;
                }
                num++;
            }
            Console.ReadKey();
        }
    }
}
