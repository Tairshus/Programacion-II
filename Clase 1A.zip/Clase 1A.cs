﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace clase_1A
{
    class Program
    {
        //static int miEntero;

        static double numeroA;
        static double numeroB;
        static int opcion;
        static string opcionS;
        static string numeroAs;
        static string numeroBs;
        static double suma;
        static double resta;
        static double producto;
        static double division;

        //static double miDouble = 20;
        //static string miPalabra;
        //static bool miBoolean;
        
        

        static void Main(string[] args)
        {
            //miEntero = (int)miDouble; //Parsear a entero un double
            //miDouble = miEntero; //No es necesario al cargar un int en double
            //miEntero = int.Parse(miPalabra); //Asi puedo meter un string en un int
            do
            {
                /*Console.WriteLine("1)Numero A = {0} \n2)Numero B = {1} \n3)Sumar \n4)Restar \n5)Multiplicar \n6)Dividir \n7)Salir", numeroA, numeroB);
                opcionS = Console.ReadLine();
                if (!(int.TryParse(opcionS, out opcion)))
                {
                    Console.WriteLine("Error, ingrese una opcion valida.");
                }
                else
                {
                    switch (opcion)
                    {
                        case 1:
                            Console.Write("\nIngrese numero A: ");
                            numeroAs = Console.ReadLine();
                            if (!(double.TryParse(numeroAs, out numeroA)))
                            {
                                Console.WriteLine("Error.");
                            }
                            break;
                        case 2:
                            Console.Write("\nIngrese numero B: ");
                            numeroBs = Console.ReadLine();
                            if (!(double.TryParse(numeroBs, out numeroB)))
                            {
                                Console.WriteLine("Error.");
                            }
                            break;
                        case 3:
                            suma = numeroA + numeroB;
                            Console.WriteLine("\nLa suma es: {0}", suma);
                            break;
                        case 4:
                            resta = numeroA - numeroB;
                            Console.WriteLine("\nLa resta es: {0}", resta);
                            break;
                        case 5:
                            producto = numeroA * numeroB;
                            Console.WriteLine("\nEl producto es: {0}", producto);
                            break;
                        case 6:
                            if (numeroB != 0)
                            {
                                division = numeroA / numeroB;
                                Console.WriteLine("\nLa division es: {0}", division);
                            }
                            else
                            {
                                Console.WriteLine("\nError no se puede dividir entre 0");
                            }
                            break;
                        case 7:
                            Console.WriteLine("\nSaliendo...");
                            break;
                        default:
                            Console.WriteLine("\nError, ingrese una opcion valida.");
                            break;
                    }*/
                Console.WriteLine("1)Sumar\n2)Restar\n3)Multiplicar\n4)Dividir\n5)Salir");
                opcionS = Console.ReadLine();
                if (!(int.TryParse(opcionS, out opcion)))
                {
                    Console.WriteLine("Error, ingrese una opcion valida.");
                }
                else if(opcion != 5)
                {
                    Console.Write("\nIngrese primer operando: ");
                    numeroAs = Console.ReadLine();
                    if (double.TryParse(numeroAs, out numeroA))
                    {
                        Console.Write("\nIngrese segundo operando: ");
                        numeroBs = Console.ReadLine();
                        if (double.TryParse(numeroBs, out numeroB))
                        {
                            miSwitch(numeroA, numeroB, opcion);
                        }
                        else
                        {
                            Console.WriteLine("Error.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error.");
                    }
                }
                else
                {
                    miSwitch(numeroA, numeroB, opcion);
                }
                Console.ReadKey();
                Console.Clear();
            } while (opcion != 5);




/*
            if(int.TryParse(miPalabra, out miEntero)) //TryParse me devolvera true o false depende de si es posible parsear todos los caracteres
            {
                miDouble = miEntero;
                miPalabra = miBoolean.ToString(); //Asi parseo un bool a un string
                System.Console.WriteLine(miPalabra);
                ConsoleKeyInfo cki = Console.ReadKey();
                Console.WriteLine(cki.Key);
              
            }*/
            //Console.ReadKey();
        }
        static void miSwitch(double numeroA, double numeroB, int opcion)
        {
            switch (opcion)
            {
                case 1:
                    suma = numeroA + numeroB;
                    Console.WriteLine("\nLa suma es: {0}", suma);
                    break;
                    break;
                case 2:
                    resta = numeroA - numeroB;
                    Console.WriteLine("\nLa resta es: {0}", resta);
                    break;
                case 3:
                    producto = numeroA * numeroB;
                    Console.WriteLine("\nEl producto es: {0}", producto);
                    break;
                case 4:
                    if (numeroB != 0)
                    {
                        division = numeroA / numeroB;
                        Console.WriteLine("\nLa division es: {0}", division);
                    }
                    else
                    {
                        Console.WriteLine("\nError no se puede dividir entre 0");
                    }
                    break;
                case 5:
                    Console.WriteLine("\nSaliendo...");
                    break;
                default:
                    Console.WriteLine("\nError, ingrese una opcion valida.");
                    break;
            }
        }
    }
}
