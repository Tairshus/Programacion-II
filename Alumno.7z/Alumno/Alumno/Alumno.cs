﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alumno
{
    public class Alumno
    {
        byte nota1;
        byte nota2;
        float notaFinal;
        public string nombre;
        public string apellido;
        public int legajo;
        public static string colegio; //Todas las instancias tendran el mismo colegio (esto por ser static)
        static Random notaFinalR;

        public Alumno(string apellido, string nombre)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.notaFinal = -1;
        }

        static Alumno()
        {
            colegio = "UTN";
            notaFinalR = new Random();
        }

        public void CalcularFinal()
        {
            if (this.nota1 >= 4 && this.nota2 >= 4)
            {
                this.notaFinal = notaFinalR.Next(1, 10);

            }
            else
            {
                this.notaFinal = -1;
            }
        }
        public void Estudiar(byte notaUno, byte notaDos)
        {
            this.nota1 = notaUno;
            this.nota2 = notaDos;
        }

        public string Mostrar()
        {
            return this.legajo.ToString() + "\n" + this.apellido + "\n" + this.nombre + "\n" + colegio + "\n" + 
                this.nota1 + "    " + this.nota2 + "\n" +
                (this.notaFinal == -1 ? "DESAPROBADO": this.notaFinal.ToString()); //colegio sin this ya que es static, no pertenece al objeto
        }
    }
    
}
