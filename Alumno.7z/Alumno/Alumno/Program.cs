﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alumno
{
    class Program
    {
        static void Main(string[] args)
        {
            byte notas1;
            byte notas2;
            Alumno alumno1 = new Alumno("Tintaya","Tairshus");
            Alumno alumno2 = new Alumno("Sandoval", "Catalina");
            Alumno alumno3 = new Alumno("Tierradentro", "Ferjerite");
            //Alumno.colegio = "UTN";
            //alumno1.apellido = "Perez";

            Console.WriteLine("Ingrese nota 1 de {0}", alumno1.apellido);
            notas1 = byte.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese nota 2 de {0}", alumno1.apellido);
            notas2 = byte.Parse(Console.ReadLine());
            alumno1.Estudiar(notas1, notas2);

            Console.WriteLine("Ingrese nota 1 de {0}", alumno2.apellido);
            notas1 = byte.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese nota 2 de {0}", alumno2.apellido);
            notas2 = byte.Parse(Console.ReadLine());
            alumno2.Estudiar(notas1, notas2);

            Console.WriteLine("Ingrese nota 1 de {0}", alumno3.apellido);
            notas1 = byte.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese nota 2 de {0}", alumno3.apellido);
            notas2 = byte.Parse(Console.ReadLine());
            alumno3.Estudiar(notas1, notas2);

            alumno1.CalcularFinal();
            alumno2.CalcularFinal();
            alumno3.CalcularFinal();

            Console.WriteLine("{0}\n\n{1}\n\n{2}",alumno1.Mostrar(),alumno2.Mostrar(),alumno3.Mostrar());          

            Console.ReadKey();
        }
    }
}
