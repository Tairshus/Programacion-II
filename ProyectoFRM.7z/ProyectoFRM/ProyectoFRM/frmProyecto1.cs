﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFRM
{
    public partial class frmProyecto1 : Form
    {
        public frmProyecto1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this.chkUsarCorreo
            //MessageBox.Show(this.chkUsarCorreo.CheckState.ToString());
            //MessageBox.Show(this.chkUsarCorreo.CheckState.ToString());
            string palabra = "";
            foreach (object item in this.lstPaises.SelectedIndex.ToString())
            {
                palabra += item.ToString();
            }

        }

        private void frmProyecto1_Load(object sender, EventArgs e)
        {

        }

        private void frmProyecto1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Desea cerrar?","Salir", MessageBoxButtons.YesNo) == DialogResult.No)
                e.Cancel = true;
        }
    }
}
